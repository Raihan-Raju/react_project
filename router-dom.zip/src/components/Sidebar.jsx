import React from 'react'
import Home from './Home'

const Sidebar = () => {
  return (
    <div>  
    <form className='form-control' action="" method="post">
      <input type="text" />
      <Home/>
    </form>
    </div>
  )
}

export default Sidebar
